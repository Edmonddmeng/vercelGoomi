# Deployment Guide for Goomi Frontend

## Deploying to Vercel

### Prerequisites
1. A Vercel account (sign up at vercel.com)
2. Your backend API deployed and accessible
3. The backend URL (e.g., `https://your-backend.com/api`)

### Deployment Steps

1. **Push to GitHub** (if not already done)
   ```bash
   git add .
   git commit -m "Ready for deployment"
   git push origin main
   ```

2. **Import to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Import your GitHub repository
   - Select the `goomi_front_end` directory as the root

3. **Configure Environment Variables**
   In Vercel project settings, add:
   ```
   NEXT_PUBLIC_API_URL=https://your-backend-url.com/api
   ```
   Replace with your actual backend URL

4. **Deploy**
   - Click "Deploy"
   - Wait for the build to complete

### Important Considerations

#### CORS Configuration
Your backend needs to allow requests from your Vercel domain. Add these CORS headers in your backend:

```javascript
// Example for Express.js backend
app.use(cors({
  origin: [
    'http://localhost:3000', // Local development
    'https://your-app.vercel.app', // Your Vercel domain
    /\.vercel\.app$/ // All Vercel preview deployments
  ],
  credentials: true, // Important for cookies
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}))
```

#### Cookie Configuration
If using cookies for authentication, ensure your backend sets cookies with:
- `SameSite=None` (for cross-origin)
- `Secure=true` (required for SameSite=None)
- Appropriate domain settings

Example:
```javascript
res.cookie('token', token, {
  httpOnly: true,
  secure: true, // Required for production
  sameSite: 'none', // For cross-origin requests
  maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
})
```

### Testing Locally with Production Backend

1. Update `.env.local`:
   ```
   NEXT_PUBLIC_API_URL=https://your-backend-url.com/api
   ```

2. Run locally:
   ```bash
   npm run dev
   ```

3. Test the authentication flow

### Troubleshooting

1. **CORS Errors**
   - Check browser console for CORS errors
   - Ensure backend allows your Vercel domain
   - Verify credentials are included in requests

2. **Authentication Not Persisting**
   - Check cookie settings in backend
   - Ensure `withCredentials: true` in API client
   - Verify cookies are being set in browser DevTools

3. **API Connection Issues**
   - Verify `NEXT_PUBLIC_API_URL` is set correctly
   - Check if backend is accessible
   - Look for network errors in browser DevTools

### Alternative: Using localStorage Instead of Cookies

If you face CORS/cookie issues, you can modify the authentication to use localStorage only:

1. Remove cookie-related code from `AuthContext.tsx`
2. Remove or simplify the middleware
3. Rely on the AuthContext redirect logic

This approach is simpler but less secure than httpOnly cookies.